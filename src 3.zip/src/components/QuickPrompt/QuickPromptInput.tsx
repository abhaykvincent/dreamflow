import { debounce } from "lodash";
import { useCallback, useEffect } from "react";

export default function QuickPromptInput({input, setInput,handleCompletions}: any) {  // Debounced to AVOID too many api calls
  const fetchApi = useCallback(debounce((input: string) => {
   handleCompletions(input);
 }, 1500), []);  
  useEffect(() => {
    if ((input.length ?? 0) > 3) {
      fetchApi(input);
    }
    return () => {
      fetchApi.cancel();
    };
  }, [input]);
  return <input className="prompt" 
    placeholder="Create a basic .." 
    type="text"
    value={input}
    onChange={(e) => setInput(e.target.value)} />;
}